from django import forms
from django.db.models.base import Model
from django.db.models.query_utils import refs_expression
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render,redirect
from django.urls import reverse
from django.forms import ModelForm, widgets
from django.urls.base import is_valid_path
from django.contrib.auth.decorators import login_required
from store.models.customer import Customer
from django.views import View
from store.models.product import Products
from store.models.orders import Order
from store.middlewares.auth import auth_middleware


class ListingForm(ModelForm):
    class Meta:
        model = Products
        fields = ['name', 'description', 'price', 'category', 'image']
        labels = {
            
        }
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': ''}),
            'description': forms.TextInput(attrs={'class': 'form-control', 'placeholder': ''}),
            'price': forms.TextInput(attrs={'class': 'form-control', 'placeholder': ''}),
            # 'category': forms.TextInput(attrs={'class': 'form-control', 'placeholder': ''}),
            # 'image': forms.TextInput(attrs={'class': 'form-control', 'placeholder': ''}),
           
        }



def newListing(request):
    if request.method == "POST":
        newListingForm = ListingForm(request.POST, request.FILES)
        if newListingForm.is_valid():
            newListing = newListingForm.save(commit=False)
            newListing.creator = request.user
            newListing.save()
            newListingForm.save_m2m()
            return redirect ('homepage')
        else:
            return render(request, "listing.html",{
                "form": newListingForm
                
            })

    else:
        return render(request, "listing.html",{
            "form": ListingForm()
            
        })
